<?php
/**
 * Serviço de Envio de Email com SMTP do cPanel
 * Este arquivo PHP recebe requisições POST e envia emails via SMTP do cPanel
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require __DIR__ . '/vendor/autoload.php';

// Habilitar todos os erros para debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Responder a preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método não permitido']);
    exit();
}

// Receber dados do POST
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Dados inválidos']);
    exit();
}

$email = $input['email'] ?? '';
$subject = $input['subject'] ?? '';
$message = $input['message'] ?? '';
$code = $input['code'] ?? '';

// Log de debug
$debugLog = date('Y-m-d H:i:s') . " - Requisição recebida\n";
$debugLog .= "Email: $email\n";
$debugLog .= "Assunto: $subject\n";
$debugLog .= "Mensagem: " . substr($message, 0, 100) . "...\n";
file_put_contents('email-debug.txt', $debugLog, FILE_APPEND);

if (!$email || !$subject || !$message) {
    http_response_code(400);
    echo json_encode(['error' => 'Campos obrigatórios faltando', 'email' => $email, 'subject' => $subject, 'has_message' => !empty($message)]);
    exit();
}

// Validação básica de email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email inválido', 'email' => $email]);
    exit();
}

// Configurações SMTP (Modo de teste - sem envio real)
// Para produção, configurar com credenciais reais do email provider
$smtpHost = 'smtp.gmail.com';
$smtpPort = 587; // TLS
$smtpSecure = PHPMailer::ENCRYPTION_STARTTLS;
$smtpUser = 'test@test.com'; // Email placeholder
$smtpPassword = 'placeholder'; // Senha placeholder
$fromEmail = 'noreply@autotradeia.net';
$fromName = 'AUTOTRADE, AI';

// Modo de teste (desativar envio real de email)
// Para enviar emails reais, altere para false e configure as credenciais acima
$testMode = true;

// Converter quebras de linha para HTML
$htmlMessage = nl2br($message);

$htmlTemplate = "
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>$subject</title>
</head>
<body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
    <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
        <div style='background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); padding: 30px; border-radius: 10px; text-align: center;'>
            <h1 style='color: #f8fafc; margin: 0;'>AUTOTRADE, AI</h1>
        </div>
        <div style='padding: 30px; background: #f8fafc; border-radius: 10px; margin-top: 20px;'>
            <h2 style='color: #1e293b;'>$subject</h2>
            <div style='color: #334155; line-height: 1.8;'>$htmlMessage</div>
        </div>
        <div style='text-align: center; margin-top: 20px; color: #64748b; font-size: 12px;'>
            <p>Este é um email automático. Por favor, não responda.</p>
            <p>&copy; 2026 AUTOTRADE, AI. Todos os direitos reservados.</p>
        </div>
    </div>
</body>
</html>
";

$mail = new PHPMailer(true);

try {
    // Modo de teste - simular envio sem conectar ao SMTP
    if ($testMode) {
        // Log do envio simulado
        $logMessage = date('Y-m-d H:i:s') . " - [MODO TESTE] Email simulado para: $email\n";
        $logMessage .= "Código de verificação: $code\n";
        $logMessage .= "Assunto: $subject\n";
        file_put_contents('email-log.txt', $logMessage, FILE_APPEND);

        echo json_encode([
            'success' => true,
            'message' => 'Email simulado com sucesso (modo teste)',
            'email' => $email,
            'code' => $code,
            'method' => 'test_mode',
            'timestamp' => date('Y-m-d H:i:s'),
            'test_mode' => true
        ]);
        exit();
    }

    // Configurações do servidor SMTP
    $mail->isSMTP();
    $mail->Host = $smtpHost;
    $mail->SMTPAuth = true;
    $mail->Username = $smtpUser;
    $mail->Password = $smtpPassword;
    $mail->SMTPSecure = $smtpSecure;
    $mail->Port = $smtpPort;
    
    // Configurações adicionais para melhorar a entrega
    $mail->SMTPKeepAlive = true;
    $mail->Timeout = 30;

    // Configurações do remetente
    $mail->setFrom($fromEmail, $fromName);
    $mail->addAddress($email);

    // Conteúdo do email
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $htmlTemplate;
    $mail->AltBody = strip_tags($htmlTemplate);

    $mail->send();

    // Log do envio
    $logMessage = date('Y-m-d H:i:s') . " - Email enviado via SMTP cPanel para: $email\n";
    $logMessage .= "Código de verificação: $code\n";
    file_put_contents('email-log.txt', $logMessage, FILE_APPEND);

    echo json_encode([
        'success' => true,
        'message' => 'Email enviado com sucesso via SMTP cPanel',
        'email' => $email,
        'code' => $code,
        'method' => 'SMTP cPanel',
        'timestamp' => date('Y-m-d H:i:s')
    ]);

} catch (Exception $e) {
    // Log do erro
    $errorLog = date('Y-m-d H:i:s') . " - Erro SMTP cPanel para: $email\n";
    $errorLog .= "Erro: " . $mail->ErrorInfo . "\n";
    $errorLog .= "Código de verificação: $code\n";
    file_put_contents('email-error.txt', $errorLog, FILE_APPEND);

    // Fallback para mail() nativa
    sendViaMail($email, $subject, $htmlTemplate, $code);
}

function sendViaMail($email, $subject, $htmlTemplate, $code) {
    global $fromEmail, $fromName;

    $headers = "From: $fromName <$fromEmail>\r\n";
    $headers .= "Reply-To: $fromEmail\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    $sent = mail($email, $subject, $htmlTemplate, $headers);

    $logMessage = date('Y-m-d H:i:s') . " - Email enviado via mail() (fallback): $email\n";
    $logMessage .= "Código de verificação: $code\n";
    file_put_contents('email-log.txt', $logMessage, FILE_APPEND);

    if ($sent) {
        echo json_encode([
            'success' => true,
            'message' => 'Email enviado com sucesso (modo fallback)',
            'email' => $email,
            'code' => $code,
            'method' => 'mail() fallback',
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            'error' => 'Erro ao enviar email (todos os métodos falharam)',
            'details' => error_get_last(),
            'email' => $email,
            'code' => $code
        ]);
    }
}
?>
